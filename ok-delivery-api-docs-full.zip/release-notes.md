---
layout: default
title: Release Notes — OK Delivery
nav_order: 3
---
# Release Notes — OK Delivery v2.4.0 (2025-10-15)
- Экран «Бонусная программа»
- Улучшена навигация в корзине
- Стабилизирован платёж по картам
